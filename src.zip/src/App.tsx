import React from 'react';
import VehicleSelector from './components/VehicleSelector';
import './styles/VehicleSelector.scss';

const App: React.FC = () => {
  return (
    <div className="app">
      <VehicleSelector />
    </div>
  );
};

export default App;