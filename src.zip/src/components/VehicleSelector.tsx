import React, { useState, useEffect, useMemo } from 'react';
import manufacturers from '../fixtures/manufacturers.json';
import models from '../fixtures/models.json';
import types from '../fixtures/types.json';
import '../styles/VehicleSelector.scss';

interface Manufacturer {
    code: string;
    name: string;
}

interface Model {
    code: string;
    name: string;
    builtFrom: string;
    builtTo: string | null;
}

interface Type {
    code: string;
    name: string;
    power: string;
    cubicCapacity: string;
}

const VehicleSelector: React.FC = () => {
    const [selectedManufacturer, setSelectedManufacturer] = useState<string>('');
    const [selectedModel, setSelectedModel] = useState<string>('');
    const [selectedType, setSelectedType] = useState<string>('');
    const [showSelection, setShowSelection] = useState<boolean>(false);

    const filteredModels = useMemo(() => {
        return selectedManufacturer ? models : [];
    }, [selectedManufacturer]);

    const filteredTypes = useMemo(() => {
        return selectedModel ? types : [];
    }, [selectedModel]);

    useEffect(() => {
        if (!selectedManufacturer) {
            setSelectedModel('');
            setSelectedType('');
        } else if (!selectedModel) {
            setSelectedType('');
        }
        setShowSelection(false); // Reset the selection view when changes happen
    }, [selectedManufacturer, selectedModel]);

    const isSelectionComplete = selectedManufacturer && selectedModel && selectedType;

    const handleOkClick = () => {
        setShowSelection(true);
    };

    const handleReset = () => {
        setSelectedManufacturer('');
        setSelectedModel('');
        setSelectedType('');
        setShowSelection(false);
    };

    return (
        <>
            <header className="header-container">
                <div className="header-overlay">
                    <h1>
                        <span>Search Electric</span> Cars for Sale
                    </h1>
                    <p>The whole universe of electric vehicles to match your needs</p>
                    <div className="header-nav">
                        <select
                            className="header-dropdown"
                            value={selectedManufacturer}
                            onChange={(e) => setSelectedManufacturer(e.target.value)}
                        >
                            <option value="">Choose Manufacturer</option>
                            {manufacturers.map((m) => (
                                <option key={m.code} value={m.code}>
                                    {m.name}
                                </option>
                            ))}
                        </select>

                        <select
                            className="header-dropdown"
                            value={selectedModel}
                            onChange={(e) => setSelectedModel(e.target.value)}
                            disabled={!selectedManufacturer}
                        >
                            <option value="">Choose Model</option>
                            {filteredModels.map((m) => (
                                <option key={m.code} value={m.code}>
                                    {m.name}
                                </option>
                            ))}
                        </select>

                        <select
                            className="header-dropdown"
                            value={selectedType}
                            onChange={(e) => setSelectedType(e.target.value)}
                            disabled={!selectedModel}
                        >
                            <option value="">Choose Type</option>
                            {filteredTypes.map((t) => (
                                <option key={t.code} value={t.code}>
                                    {t.name}
                                </option>
                            ))}
                        </select>
                        <button
                            className="btn btn-secondary"
                            onClick={handleReset}
                        >
                            RESET
                        </button>
                        <button className="header-button SearchBtn"
                            disabled={!isSelectionComplete}
                            onClick={handleOkClick}>Find Your EV</button>
                    </div>
                </div>
            </header>
            {showSelection && (
            <div className="container my-4">
            <h2 className='mb-3 text-center'>Your Selection</h2>
            <div className="vehicle-selector">
              <div className="selection-summary mt-4">
              
                <table>
                  <thead>
                    <tr>
                      <th>Attribute</th>
                      <th>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Manufacturer</td>
                      <td>{manufacturers.find(m => m.code === selectedManufacturer)?.name}</td>
                    </tr>
                    <tr>
                      <td>Model</td>
                      <td>{models.find(m => m.code === selectedModel)?.name}</td>
                    </tr>
                    <tr>
                      <td>Power</td>
                      <td>{types.find(t => t.code === selectedType)?.power}</td>
                    </tr>
                    <tr>
                      <td>Cubic Capacity</td>
                      <td>{types.find(t => t.code === selectedType)?.cubicCapacity}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          
            )}
        </>
    );
};

export default VehicleSelector;
